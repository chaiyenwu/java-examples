public class Error{
	public static void main(String[] args){
		int x=5;
		int y=0;
		int z=x/y;
		System.out.println(z);
		System.out.println("error");
	}
}