import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
public class Redirection{
   public static void main(String[] args){
      PrintStream errorStream = null;
      try{
          errorStream =  new PrintStream(
                          new FileOutputStream("error.txt"));
      }catch(FileNotFoundException e){
         System.out.println("�L�k�ϥ�FileOutputStream���}�ɮ�");
      }
      System.setErr(errorStream);
      System.out.println("System.out��Hello");
      System.err.println("System.err��Hello");      
      errorStream.close( );
   }
}



