public class Error_Exception extends Exception{
   Error_Exception (String message){
      super (message);
   }
}
