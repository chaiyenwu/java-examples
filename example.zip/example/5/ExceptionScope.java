public class ExceptionScope{
   public void level1(){
      System.out.println("Level 1 �}�l�I�s");
      try{
         level2();
      }catch (ArithmeticException problem){
         System.out.println ();
         System.out.println ("�ҥ~���T���O: " +
                             problem.getMessage());
         System.out.println ();
         System.out.println ("The call stack trace:");
         problem.printStackTrace();
         System.out.println ();
      }

      System.out.println("Level 1 ����");
   }
   public void level2(){
      System.out.println("Level 2 �}�l");
      level3 ();
      System.out.println("Level 2 ����");
   }
   public void level3(){
      int x = 5, y = 0;
      System.out.println("Level 3 �}�l");
      int result = x / y;
      System.out.println("Level 3 ����");
   }
}
