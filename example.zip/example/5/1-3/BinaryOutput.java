import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class BinaryOutput{
   public static void main(String[] args){
      try{
         ObjectOutputStream outputStream =
             new ObjectOutputStream(new FileOutputStream("Binary.dat"));
         int i;
         for (i = 0; i < 258; i++)
             outputStream.writeInt(i);
         System.out.println("�g��Binary.dat�줸�ɮ�.");
         outputStream.close( );
      }catch(IOException e){
         System.out.println("��X�����D");
      }
   }
}

