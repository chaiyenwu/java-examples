import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.FileNotFoundException;
public class BinaryEOF{
    public static void main(String[] args){
        try{
            ObjectInputStream inputStream =
              new ObjectInputStream(new FileInputStream("Binary.dat"));
            int number;
            System.out.println("�qBinary.dat�G�i���ɮ�Ū�����");
            try{
                while (true){
                    number = inputStream.readInt( );
                    System.out.print(number+" ");
                }
            }catch(EOFException e){
                System.out.println("�̫�@��F");
            }
            inputStream.close( );
        }catch(FileNotFoundException e){
            System.out.println("�L�k���Binary.dat�ɮ�");
        }catch(IOException e){
            System.out.println("�L�k�qBinary.dat��J�ɮ�");
        }
    }
}

