import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
public class ObjectIO{
   public static void main(String[] args){
      try{
          ObjectOutputStream outputStream =
             new ObjectOutputStream(new FileOutputStream("datafile.dat"));
          MyClass oneObject = new MyClass(1, 'B');
          MyClass anotherObject = new MyClass(2, 'C');
          outputStream.writeObject(oneObject);
          outputStream.writeObject(anotherObject);
          outputStream.close( );
          System.out.println("�N��ưe���ɮפ�");
      }
      catch(IOException e){
         System.out.println("�ɮ׿�X�����D");
      }
        System.out.println("���s���}�ɮשM��ܸ��");
      try{
          ObjectInputStream inputStream = 
            new ObjectInputStream(new FileInputStream("datafile.dat"));
          MyClass One = (MyClass)inputStream.readObject( );
          MyClass Two = (MyClass)inputStream.readObject( );
          System.out.println("�qdatafile.dat�G�i����Ū�����");
          System.out.println(One);
          System.out.println(Two);
      }catch(FileNotFoundException e){
          System.out.println("�L�k���}�G�i��datafile.dat�ɮ�");
      }catch(ClassNotFoundException e){
          System.out.println("�ɮ׵L�k���");
      }catch(IOException e){
          System.out.println("�ɮ׿�J�����D");
      }
      System.out.println("�{������");
   }
}

 