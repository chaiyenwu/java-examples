import java.io.*;
public class FileWriter_test {
  public static void main(String[] args) throws IOException {
    FileWriter output = new FileWriter("good.txt", true);
    output.write("�o�O�n��X���r");
    output.close();
  }
}
