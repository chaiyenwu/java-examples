import java.util.HashSet;
import java.util.Iterator;
public class HashSetIteratorTest{
    public static void main(String[] args){
        HashSet s = new HashSet( );
        s.add("PHP&MySQL������s");
        s.add("Flash MX2004������s");
        s.add("Linux Fedora������s");
        System.out.println("�o���X�]�t:");
        Iterator i = s.iterator( );
        while (i.hasNext( )){
            System.out.println(i.next( ));
	}
        i.remove( );
        System.out.println( );
        System.out.println("�R���@�Ӥ���:");
        i = s.iterator( );
        while (i.hasNext( )){
            System.out.println(i.next( ));
	}
    }
}
