public class ABook{
   private String title;
   public ABook (String newTitle){    
      title = newTitle;
   }
   public String toString(){
      return title;
   }
}
