public class Animal_overriding{
	private String type;
	public Animal_overriding(String animaltype){
		type=new String(animaltype);
	}
	public String toString(){
		return "�o�O�@��"+type;
	}
}

