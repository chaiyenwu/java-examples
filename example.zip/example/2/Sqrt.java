public class Sqrt{
    public static void main(String[] args){      
       double i=Math.sqrt(4);
       System.out.println(i);         
    }
}