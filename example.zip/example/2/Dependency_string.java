public class Dependency_string{
	    public static void main(String[] args){  
	      String s=new String("�w��Ө�Java");
	      String s1=new String("�j�a�n");
	      String s3=s.concat(s1);	          
          System.out.println(s3);
    }

}