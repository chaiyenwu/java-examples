public class Dog extends Animal {
	private String name;
	public Dog(String aName){
		super("Dog");
		name=aName;
	}
	public String toString(){
		return "�o�O�@��"+name;
	}
	public void sound(){
		System.out.println("����");
	}
}