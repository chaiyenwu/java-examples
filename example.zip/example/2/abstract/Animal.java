public abstract class Animal{
	private String type;
	public abstract void sound();
	public Animal(String aType){
		type=new String(aType);
	}
	public String toString(){
		return "�o�O�@��"+type;
	}
}

