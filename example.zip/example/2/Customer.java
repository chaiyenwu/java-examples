public class Customer{
           String name;
           String address;
           char level;
           public char credit(){
           	this.level=level;
           	return level;
           }
    }

