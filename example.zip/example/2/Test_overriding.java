public class Test_overriding{
	public static void main(String[] args){
		Dog_overriding littledog1=new Dog_overriding("�p��");
		Dog_overriding littledog2=new Dog_overriding("�p��","�x�W�g��");
		System.out.println(littledog1);
		System.out.println(littledog2);
	}
}