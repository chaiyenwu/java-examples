public class Dog_overriding extends Animal_overriding{
	private String name;
	private String breed;
	public Dog_overriding(String dogname){
		super("Dog_overriding");
		name=dogname;
		breed="�����D�~��";
	}
	public Dog_overriding(String dogname,String dogbreed){
		super("Dog");
		name=dogname;
		breed=dogbreed;
	}
	public String toString(){
		return "�o�O�@��"+breed+",�����W�l�O"+name;
	}
}