public interface PetOutput{
	void sound();
}