public class Animal{
	private String type;
	public Animal(String aType){
		type=new String(aType);
	}
	public String toString(){
		return "�o�O�@��"+type;
	}
}

