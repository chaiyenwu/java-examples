public class Test{
	public static void main(String[] args){
		Dog littledog1=new Dog("�p��");
		Dog littledog2=new Dog("�p��");
		System.out.println(littledog1);
		System.out.println(littledog2);
	}
}