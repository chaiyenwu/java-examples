public class Name implements Cloneable{
	private String myname;
	public Name(){
		this("�d�夤");
	}
	public Name(String myname){
		this.myname=myname;
	}
	public String getmyname(){
		return myname;
	}
	public void setmyname(){
		this.myname=myname;		
	}
}

