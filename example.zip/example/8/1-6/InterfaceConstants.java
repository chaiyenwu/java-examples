public interface InterfaceConstants {
  public static int PLAYER1 = 1; 
  public static int PLAYER2 = 2; 
  public static int PLAYER1_WON = 1; 
  public static int PLAYER2_WON = 2; 
  public static int EQUAL = 3; 
  public static int CONTINUE = 4; 
}
