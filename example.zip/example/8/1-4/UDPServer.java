import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
public class UDPServer extends JFrame
{
   private JTextArea AreaDisplay;
   private DatagramSocket UDPsocket;
   public static void main( String args[] )
   {
      UDPServer UDPS = new UDPServer();
      UDPS.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      UDPS.waitForPackets();
   }
   public UDPServer()
   {
      super( "�ϥ�UDP��w�����A��" );
      AreaDisplay = new JTextArea();
      add( new JScrollPane( AreaDisplay ), BorderLayout.CENTER );
      setSize( 300, 300 );
      setVisible( true );
      try {
         UDPsocket = new DatagramSocket( 9000 );
      } catch ( SocketException socketException ){
         socketException.printStackTrace();
         System.exit( 1 );
      }
   }
   public void waitForPackets()
   {
      while ( true )
      {
         try{
            byte data[] = new byte[ 100 ];
            DatagramPacket receivePacket =
               new DatagramPacket( data, data.length );
            UDPsocket.receive( receivePacket );
            displayMessage( "\n�ʥ]����:" +
               "\n�q�D��: " + receivePacket.getAddress() +
               "\n�D���s����: " + receivePacket.getPort() +
               "\n��ƪ���: " + receivePacket.getLength() +
               "\n�]�t:\n\t" + new String( receivePacket.getData(),
                  0, receivePacket.getLength() ) );
            sendPacketToClient( receivePacket );
         }catch ( IOException ioException )
         {
            displayMessage( ioException.toString() + "\n" );
            ioException.printStackTrace();
         }
      }
   }
   private void sendPacketToClient( DatagramPacket receivePacket )
      throws IOException
   {
      displayMessage( "\n\n�^���ϥΪ̺ݪ����" );
      DatagramPacket sendPacket = new DatagramPacket(
         receivePacket.getData(), receivePacket.getLength(),
         receivePacket.getAddress(), receivePacket.getPort() );

      UDPsocket.send( sendPacket );
      displayMessage( "�ʥ]�ǰe\n" );
   }
   private void displayMessage( final String messageToDisplay )
   {
      SwingUtilities.invokeLater(
         new Runnable()
         {
            public void run(){
               AreaDisplay.append( messageToDisplay );
            }
         }
      );
   }
}

