import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;

public class ServerThread extends JFrame {
  private JTextArea TextArea1 = new JTextArea();
  public static void main(String[] args) {
    new ServerThread();
  }
  public ServerThread() {
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(new JScrollPane(TextArea1), BorderLayout.CENTER);
    setTitle("�h��������A��");
    setSize(300, 200);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true); 
    try {
      ServerSocket serverSocket = new ServerSocket(9000);
      TextArea1.append("�h��������A���}�l" + new Date() + '\n');
      int clientNo = 1;
      while (true) {
        Socket socket = serverSocket.accept();
        TextArea1.append("�}�l��������"+clientNo+"�b"+new Date()+'\n');
        InetAddress inetAddress = socket.getInetAddress();
        TextArea1.append("�ϥΪ� "+clientNo+"���W�٬O"
          + inetAddress.getHostName() + "\n");
        TextArea1.append("�ϥΪ�"+clientNo+"��IP��m"
          + inetAddress.getHostAddress() + "\n");
        HandleAClient thread = new HandleAClient(socket);
        thread.start();
        clientNo++;
      }
    }
    catch(IOException ex) {
      System.err.println(ex);
    }
  }
  class HandleAClient extends Thread {
    private Socket socket;
    public HandleAClient(Socket socket) {
      this.socket = socket;
    }

    public void run() {
      try {
        DataInputStream inputFromClient = new DataInputStream(
          socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(
          socket.getOutputStream());
        while (true) {
          double radius = inputFromClient.readDouble();
          double area = radius * radius * Math.PI;
          outputToClient.writeDouble(area);
          TextArea1.append("�ϥΪ̺ݿ�J���b�|" +
            radius + '\n');
          TextArea1.append("�ꪺ���n" + area + '\n');
        }
      }catch(IOException e) {
        System.err.println(e);
      }
    }
  }
}

