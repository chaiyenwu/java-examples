import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Container;
import java.awt.BorderLayout;
public class BorderLayout1 extends JFrame
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 300;
    public BorderLayout1( )
    {
        super("�ܽd�G�m���" );
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container contentPane = getContentPane( );
        contentPane.setLayout(new BorderLayout( ));
        JLabel labelNorth = new JLabel("            ����NORTH");
        contentPane.add(labelNorth, BorderLayout.NORTH); 
        JLabel labelCenter = new JLabel("           ����CENTER");
        contentPane.add(labelCenter, BorderLayout.CENTER); 
        JLabel labelSouth = new JLabel("            ����SOUTH");
        contentPane.add(labelSouth, BorderLayout.SOUTH); 
        JLabel labelWest = new JLabel("����WEST");
        contentPane.add(labelWest, BorderLayout.WEST); 
        JLabel labelEast = new JLabel("����EAST");
        contentPane.add(labelEast, BorderLayout.EAST); 
    }
}
