import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class TextFieldTest extends JFrame implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;
    public static final int NUMBER_OF_CHAR = 30;
    private JTextField name;
    public static void main(String[] args)
    {
        TextFieldTest Text1 = new TextFieldTest( );
        Text1.setVisible(true);
    }
    public TextFieldTest( )
    {
        super("��r������");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container content = getContentPane( );
        content.setLayout(new GridLayout(2, 1));        
        JPanel namePanel = new JPanel( ); 
        namePanel.setLayout(new BorderLayout( ));
        namePanel.setBackground(Color.GREEN); 
        name = new JTextField(NUMBER_OF_CHAR);
        namePanel.add(name, BorderLayout.SOUTH);
        JLabel nameLabel = new JLabel("�b�o�̿�J�A���W�l:");
        namePanel.add(nameLabel, BorderLayout.CENTER);
        content.add(namePanel);
        JPanel buttonPanel = new JPanel( );
        buttonPanel.setLayout(new FlowLayout( ));
        buttonPanel.setBackground(Color.YELLOW); 
        JButton actionButton = new JButton("���U�h"); 
        actionButton.addActionListener(this);
        buttonPanel.add(actionButton);
        JButton clearButton = new JButton("�M��"); 
        clearButton.addActionListener(this);
        buttonPanel.add(clearButton); 
        content.add(buttonPanel);
    }
    public void actionPerformed(ActionEvent e) 
    {
        String actionCommand = e.getActionCommand( );

        if (actionCommand.equals("���U�h"))
            name.setText("���o"+name.getText()+"�A�n");
        else if (actionCommand.equals("�M��"))
            name.setText("");
        else
            name.setText("Unexpected error.");
    } 
}


