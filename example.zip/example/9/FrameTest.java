public class FrameTest
{
    public static void main(String[] args) 
    {
        Frame1 f = new Frame1( );
        f.setVisible(true);
    }
}
