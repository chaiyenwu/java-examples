public class FlowLayoutTest
{
    public static void main(String[] args) 
    {
        FlowLayout1 Fl = new FlowLayout1( );
        Fl.setVisible(true);
    }
}
