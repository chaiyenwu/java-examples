import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Container;
import java.awt.GridLayout;
public class GridLayout1 extends JFrame
{
    public static final int WIDTH = 400;
    public static final int HEIGHT = 200;
    public static void main(String[] args)
    {
        GridLayout1 Grid = new GridLayout1(2, 4);
        Grid.setVisible(true);
    }
    public GridLayout1(int rows, int columns )
    {
        super( );
        setSize(WIDTH, HEIGHT);
        setTitle("�ܽd�G�m��l");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container contentPane = getContentPane( );
        contentPane.setLayout(new GridLayout(rows, columns ));
        JLabel label1 = new JLabel("�Ĥ@�Ӽ���");
        contentPane.add(label1);
        JLabel label2 = new JLabel("�ĤG�Ӽ���");
        contentPane.add(label2);
        JLabel label3 = new JLabel("�ĤT�Ӽ���");
        contentPane.add(label3);
        JLabel label4 = new JLabel("�ĥ|�Ӽ���");
        contentPane.add(label4);
        JLabel label5 = new JLabel("�Ĥ��Ӽ���");
        contentPane.add(label5);
        JLabel label6 = new JLabel("�Ĥ��Ӽ���");
        contentPane.add(label6);
        JLabel label7 = new JLabel("�ĤC�Ӽ���");
        contentPane.add(label7);
        JLabel label8 = new JLabel("�ĤK�Ӽ���");
        contentPane.add(label8);
    }
}
