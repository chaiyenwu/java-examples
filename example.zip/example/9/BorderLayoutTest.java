public class BorderLayoutTest
{
    public static void main(String[] args) 
    {
        BorderLayout1 Bo = new BorderLayout1( );
        Bo.setVisible(true);
    }
}
