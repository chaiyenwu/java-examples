import javax.swing.*;
public class Applet1 extends JApplet
{
   public void init()
   {
      JLabel label = new JLabel("�j�a�n,JApplet", SwingConstants.CENTER);
      add(label);
   }
}
