import java.awt.Container;
import javax.swing.*;
public class Applet2 extends JApplet
{
   public Applet2()
   {
      JLabel label = new JLabel("�j�a�n,JApplet", SwingConstants.CENTER);
      Container contentPane=getContentPane();
      contentPane.add(label);
   }
}
