public class Test{
	public static void main(String[] arg){
		KeyValueTable<String, Integer> grades=
		             new  KeyValueTable<String, Integer>();
		grades.add("�d�ο�",new Integer(99));
		grades.add("�G�Jī",new Integer(98));
		System.out.println("�d�ߧd�οΪ����Z");
		Integer wuGrade=grades.lookUp("�d�ο�");
		System.out.println(wuGrade);
	}
}

