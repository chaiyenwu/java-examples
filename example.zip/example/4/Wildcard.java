import java.util.ArrayList;
public class Wildcard{
   public static double sum( ArrayList< ? extends Number > list ){
      double total = 0; 
      for ( Number element : list ){
         total += element.doubleValue();
      }
      return total;
   } 
   public static void main( String args[] ){
      Integer[] integers = { 2, 4, 6, 8, 10 };
      ArrayList< Integer > integerList = new ArrayList< Integer >();
      for ( Integer element : integers ){
         integerList.add( element );
      }
      System.out.printf( "��Ʀ�C�]�t: %s\n", integerList );
      System.out.printf("�b��Ʀ�C���Ҧ��������X: %.0f\n\n",sum( integerList ));
      Double[] doubles = { 1.1, 2.1, 3.1 };
      ArrayList< Double > doubleList = new ArrayList< Double >();
      for ( Double element : doubles ){
         doubleList.add( element );
      }
      System.out.printf( "����ׯB�I�ƥ]�t: %s\n", doubleList );
      System.out.printf("�b����ׯB�I�Ʀ�C���Ҧ��������X: %.1f\n\n",
                                                   sum( doubleList ) );
      Number[] numbers = { 1.1, 2, 3.1, 4,5.1 }; 
      ArrayList< Number > numberList = new ArrayList< Number >();
      for ( Number element : numbers ){
         numberList.add( element );
      }
      System.out.printf( "�ƭȦ�C�]�t: %s\n", numberList );
      System.out.printf( "�b�ƭȦ�C���Ҧ��������X: %.1f\n", 
         sum( numberList ) );
   } 
} 

