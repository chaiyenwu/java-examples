public class Test2{
	public static void main(String[] arg){
		KeyValueTable<String, Character> grades=
		             new  KeyValueTable<String, Character>();
		grades.add("�d�ο�",new Character('A'));
		grades.add("�G�Jī",new Character('B'));
		System.out.println("�d�ߧd�οΪ����Z");
		Character wuGrade=grades.lookUp("�d�ο�");
		System.out.println(wuGrade);
	}
}

