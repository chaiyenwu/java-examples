import java.util.TreeSet;  
class TreeSet2{  
 public static void main(String args[]){  
 TreeSet<String> set=new TreeSet<String>();  
         set.add("Mary");  
         set.add("John");  
         set.add("Apple");  
         set.add("Justin");
         set.add("Cat");
         System.out.print(set);  
 }  
}  